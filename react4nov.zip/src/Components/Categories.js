const Categories = [
    {
        id: 1,
        title: "watch",
        image: "../images (1).jpeg",

    },
    {
        id: 1,
        title: "watch",
        image: "../download (1).jpeg",

    },
   
    {
        id: 1,
        title: "watch",
        image: "../download.jpeg",

    },

    {
        id: 1,
        title: "watch",
        image: "../images (1).jpeg",

    },

    {
        id: 1,
        title: "watch",
        image: "../images (1).jpeg",

    },

    {
        id: 1,
        title: "watch",
        image: "../images (1).jpeg",

    },

    {
        id: 1,
        title: "watch",
        image: "../images (1).jpeg",

    },

    {
        id: 1,
        title: "watch",
        image: "../images (1).jpeg",

    },
    {
        id: 1,
        title: "watch",
        image: "../images (1).jpeg",

    },



]
export default Categories;